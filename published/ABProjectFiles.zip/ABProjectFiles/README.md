# ABProjectFiles

ABProjectFiles is a Lazarus IDE plugin that helps view and open current project files.

### Installation:
To install, simply download as zip and use Lazarus IDE to open, compile and install.

Package -> Open Package File
then click Compile and then Use -> Install

### Dependencies:
Install IDEIntf from the package -> Install/Uninstall Packages.

Thanks.
