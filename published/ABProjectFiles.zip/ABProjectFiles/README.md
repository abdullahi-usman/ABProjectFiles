# ABProjectFiles

ABProjectFiles is a Lazarus IDE plugin that helps view and open current project files.

After installation goto View -> Project Files.

### Installation:
To install, simply download as zip and use Lazarus IDE to open, compile and install.

Package -> Open Package File
then click Compile and then Use -> Install

### Dependencies:
CodeTools, IDEIntf

Install from the package manager within the editor.

Package -> Install/Uninstall Packages.

Thanks.
